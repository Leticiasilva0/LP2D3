<!DOCTYPE html>
<html>
<head>
    <title>Saldo Bancário</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css\style.css">
</head>
<body>

<?php
  if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $nome = $_POST["nome"];
    $idade = $_POST["idade"];
    $profissao = $_POST["profissao"];
    
    $saldo = rand(-100000, 100000);
    
    echo "<div class='container'>";

    echo "<h1>Olá, meu nome é $nome, tenho $idade anos e sou $profissao.</h1><br>";
    
    
    if ($saldo < 0) {
        echo "<h2>Saldo na conta bancaria negativa: R$ $saldo </h2><br>";
        echo "Veja alguns cursos de programação para ganhar dinheiro e sair das dívidas:<br><br>";
        echo "<strong>Cursos:<br></strong>";
        echo "- Introdução à Programação - https://www.youtube.com/curso1<br>";
        echo "- Desenvolvimento Web com PHP - https://www.youtube.com/curso2<br>";
        echo "- Machine Learning Básico - https://www.youtube.com/curso3<br>";
    } else {
        echo "<h2>Seu saldo da conta bancária é de: R$ $saldo </h2><br>";
        echo "Veja algumas ofertas de produtos para você e alguns cursos:<br><br>";
        echo "<strong>Cursos:</strong><br>";
        echo "- Introdução à Programação - https://www.youtube.com/curso1<br>";
        echo "- Desenvolvimento Web com PHP - https://www.youtube.com/curso2<br>";
        echo "- Machine Learning Básico - https://www.youtube.com/curso3<br>";
        echo "<strong>Produtos:</strong><br>";
        echo "- Produto A - R$ 50<br>";
        echo "- Produto B - R$ 75<br>";
        echo "- Produto C - R$ 120<br>";
    }
    echo "</div>";

}


?>

</form>
</body>
</html>