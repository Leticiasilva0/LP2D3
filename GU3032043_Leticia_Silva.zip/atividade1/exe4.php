<!DOCTYPE html>
<html>
<head>
    <title>Saldo Bancário</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css\style.css">
</head>
<body>

<?php
class Curso {
    private $nome;
    private $link;

    public function __construct($nome, $link) {
        $this->nome = $nome;
        $this->link = $link;
    }

    public function getNome() {
        return $this->nome;
    }

    public function getLink() {
        return $this->link;
    }
}

$catalogoCursos = array(
    new Curso("Desenvolvimento Web com HTML e CSS", "https://www.youtube.com/curso1"),
    new Curso("Inglês Básico ao Avançado", "https://www.youtube.com/curso2"),
    new Curso("Microsoft Excel Avançado", "https://www.youtube.com/curso3"),
    new Curso("Java para Iniciantes", "https://www.youtube.com/curso4"),
    new Curso("Marketing Digital", "https://www.youtube.com/curso5")
);

// Função para exibir os cursos do catálogo
function exibirCatalogo($catalogoCursos) {
    echo "<div class='container'>";
    echo "<h2>Catalogo de Cursos no YouTube</h2><br>";
    foreach ($catalogoCursos as $curso) {
        echo "<strong>Curso de " . $curso->getNome() . " <br>Link: </strong>" . $curso->getLink() . "<br><br>";
    }
    echo "</div>";
}

// Exibindo o catálogo de cursos
exibirCatalogo($catalogoCursos);

?>

</body>
</html>