<!DOCTYPE html>
<html>
<head>
    <title>Saldo Bancário</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css\style.css">
</head>
<body>

<?php
class Pessoa {
    private $nome;
    private $idade;
    private $profissao;


    public function __construct($nome, $idade, $profissao) {
        $this->nome = $nome;
        $this->idade = $idade;
        $this->profissao = $profissao;
    }

    public function apresentar() {
        return "<h2>Olá, meu nome é " . $this->nome . ", tenho " . $this->idade . " anos e sou " . $this->profissao . ".</h2>";
    }
}

$pessoa1 = new Pessoa("Maria", 22, "Cientista");
echo "<div class='container'>";
echo $pessoa1->apresentar();
echo "</div>";
?>
</body>
</html>


