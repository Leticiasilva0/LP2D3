<!DOCTYPE html>
<html>
<head>
    <title>Saldo Bancário</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css\style.css">
</head>
<body>


<?php
class Produto {
    private $nome;
    private $preco;

    public function __construct($nome, $preco) {
        $this->nome = $nome;
        $this->preco = $preco;
    }

    public function getNome() {
        return $this->nome;
    }

    public function getPreco() {
        return $this->preco;
    }
}

function exibirCatalogo($catalogo) {
    echo "<div class='container'>";
    echo "<h2>Catalago de Produtos</h2><br>";
    foreach ($catalogo as $produto) {
        echo "<strong>" . $produto->getNome() . "</strong><br> Preço: R$ " . $produto->getPreco() . "<br><br>";
    }
    echo "</div>";
}

$catalogo = array(
    new Produto("Banana", 7.99),
    new Produto("Maçã", 2.50),
    new Produto("Uva", 10.00),
    new Produto("Melancia", 30.00),
    new Produto("Abacate", 5.99),
    new Produto("Laranja", 2.99),
    new Produto("Manga", 3.99),
    new Produto("Melão", 5.00)
);


exibirCatalogo($catalogo);
?>
</body>
</html>