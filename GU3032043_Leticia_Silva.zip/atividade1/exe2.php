<!DOCTYPE html>
<html>
<head>
    <title>Saldo Bancário</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css\style.css">
</head>
<body>

<?php
class ContaBancaria {
    private $titular;
    private $numero;
    private $saldo;

    public function __construct($titular, $numero, $saldo = 0) {
        $this->titular = $titular;
        $this->numero = $numero;
        $this->saldo = $saldo;
    }
    public function apresentar() {
        return "<h1>Olá, " . $this->titular . ".</h1><br><h2> Numero da conta: " . $this->numero . "<br>Saldo da conta: R$ " . $this->saldo . ".</h2><br><br>";
    }
    public function deposito($valor) {
        $this->saldo += $valor;
        return "Seu depósito de R$ " . $valor . " foi realizado com sucesso. Seu saldo atual é: R$ " . $this->saldo . ".<br>";
    }

    public function saque($valor) {
        if ($valor > $this->saldo) {
            return "Saque não realizado. Seu saldo R$" . $this->saldo . " é menor do que o R$" . $valor . ". Tente novamente com outro valor.<br>";
        } else {
            $this->saldo -= $valor;
            return "O valor de R$ " . $valor . " foi sacado com sucesso. Seu saldo atual é: R$ " . $this->saldo . ".<br>";
        }
    }
}

$conta1 = new ContaBancaria("Melissa", "123456", "1000");
echo "<div class='container'>";
echo $conta1->apresentar();
echo $conta1->deposito(1000);
echo $conta1->deposito(2000);
echo $conta1->saque(170);
echo $conta1->saque(6000);
echo "</div>";
?>
</body>
</html>