<!DOCTYPE html>
<html>
<head>
    <title>Formulario conta bancaria</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css\style.css">
</head>
<body>
    <div class="container">

        <form method="post" action="saldoBanco.php">
            <div class="form-group">
                <label for="largura">Nome:</label>
                <input type="text" class="form-control" id="nome" name="nome" required>
            </div>
            <div class="form-group">
                <label for="altura">Idade:</label>
                <input type="number" class="form-control" id="idade" name="idade" required>
            </div>
            <div class="form-group">
                <label for="altura">Profissão:</label>
                <input type="text" class="form-control" id="profissao" name="profissao" required>
            </div>
            
            <button type="submit" class="btn btn-primary">Entrar</button>
        </form>
        
    </div>
</body>
</html>